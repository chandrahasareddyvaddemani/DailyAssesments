package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringOneToManyproject2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringOneToManyproject2Application.class, args);
	}

}
